const fs = require("fs");
const chalk = require('chalk');
const moment = require("moment-timezone");

//Setting order kuota
global.okeUrl = "https://okeconnect.com/harga/json?id=905ccd028329b0a" //Untuk cara mendapatkannya chat https://wa.me/6281904092095
global.memberId = "OK******" //Untuk cara mendapatkannya chat https://wa.me/6281904092095
global.pin = "****" //Pin order kuota
global.pw = "******" //Password order kuota

//Pairing Code
global.pairingCode = true //true = gausah scan qr cukup 1 hp || false = harus scan qr dan 2 hp

//Persentase default
global.pajak = "2" //Biaya admin saat deposit
global.untung = "5" //Persentase keuntungan

//Other
global.botName = "R¡zzxteam" //Nama bot
global.owner = ["6282230002820"] //Ganti agar fitur owner bisa digunakan
global.ownerNomer = "6282230002820" //Nomor lu
global.ownerName = "R¡zzxteam" //Nama lu
global.packname = "© R¡zzxteam" //Sticker wm ubah
global.author = "Di Buat Oleh R¡zzxteam" //Sticker wm ubah nama lu
global.footer = "R¡zzxteam" //Seterah
global.sessionName = "session" //Ngga usah di ganti

//Message
global.mess = {
  sukses: "Done🤗",
  admin: "Command ini hanya bisa digunakan oleh Admin Grup",
  botAdmin: "Bot Harus menjadi admin",
  owner: "Command ini hanya dapat digunakan oleh owner bot",
  prem: "Command ini khusus member premium",
  group: "Command ini hanya bisa digunakan di grup",
  private: "Command ini hanya bisa digunakan di Private Chat",
  wait: "⏳ Mohon tunggu sebentar...",
  error: {
    lv: "Link yang kamu berikan tidak valid",
    api: "Maaf terjadi kesalahan"
  }
}

//Payment
global.payment = {
  qris: {
    link: "-", //Link foto qris
    an: "-" //Atas nama qris
  },
  dana: {
    nope: "082230002820", //Nomor akun dana
    an: "R... Y..." //Atas nama akun dana
  }
}

let time = moment(new Date()).format('HH:mm:ss DD/MM/YYYY')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
  fs.unwatchFile(file)
  console.log(chalk.greenBright(`[ ${botName} ]  `) + time + chalk.cyanBright(` "${file}" Telah diupdate!`))
  delete require.cache[file]
  require(file)
})