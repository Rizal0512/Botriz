require("./setting.js")
const { downloadContentFromMessage } = require('@adiwajshing/baileys');
const fs = require("fs");
const moment = require("moment-timezone");
const toMs = require('ms');
const ms = require('parse-ms');
const os = require('os');
const speed = require("performance-now");
const util = require('util');
const { exec } = require("child_process");
const { sizeFormatter } = require('human-readable');
const cron = require("node-cron");
const axios = require("axios");

const { getGroupAdmins, runtime, sleep } = require("./function/myfunc");
const { addResponList, delResponList, isAlreadyResponList, isAlreadyResponListGroup, sendResponList, updateResponList, getDataResponList } = require('./function/respon-list');
const { addResponTesti, delResponTesti, isAlreadyResponTesti, updateResponTesti, getDataResponTesti } = require('./function/respon-testi');
const { color } = require('./function/console');
const { TelegraPh } = require('./function/uploader');
const { expiredCheck, getAllSewa } = require("./function/sewa");
global.prefa = ['', '.']

moment.tz.setDefault("Asia/Jakarta").locale("id");
const d = new Date
const tanggal = d.toLocaleDateString('id', {
  day: 'numeric',
  month: 'long',
  year: 'numeric'
})

module.exports = async (ronzz, msg) => {
  try {
    const { type, quotedMsg, fromMe } = msg
    if (msg.isBaileys) return
    const jamwib = moment.tz('asia/jakarta').format('HH:mm:ss')
    const jamwita = moment.tz('asia/makassar').format('HH:mm:ss')
    const jamwit = moment.tz('asia/jayapura').format('HH:mm:ss')
    const dt = moment.tz('Asia/Jakarta').format('HH')
    const content = JSON.stringify(msg.message)
    const from = msg.key.remoteJid
    const chats = (type === 'conversation' && msg.message.conversation) ? msg.message.conversation : (type === 'imageMessage') && msg.message.imageMessage.caption ? msg.message.imageMessage.caption : (type === 'videoMessage') && msg.message.videoMessage.caption ? msg.message.videoMessage.caption : (type === 'extendedTextMessage') && msg.message.extendedTextMessage.text ? msg.message.extendedTextMessage.text : (type === 'buttonsResponseMessage') && quotedMsg.fromMe && msg.message.buttonsResponseMessage.selectedButtonId ? msg.message.buttonsResponseMessage.selectedButtonId : (type === 'templateButtonReplyMessage') && quotedMsg.fromMe && msg.message.templateButtonReplyMessage.selectedId ? msg.message.templateButtonReplyMessage.selectedId : (type === 'messageContextInfo') ? (msg.message.buttonsResponseMessage?.selectedButtonId || msg.message.listResponseMessage?.singleSelectReply.selectedRowId) : (type == 'listResponseMessage') && quotedMsg.fromMe && msg.message.listResponseMessage.singleSelectReply.selectedRowId ? msg.message.listResponseMessage.singleSelectReply.selectedRowId : ""
    const toJSON = j => JSON.stringify(j, null, '\t')
    const prefix = prefa ? /^[°•π÷×¶∆£¢€¥®=????+✓_=|~!?@#%^&.©^]/gi.test(chats) ? chats.match(/^[°•π÷×¶∆£¢€¥®=????+✓_=|~!?@#%^&.©^]/gi)[0] : "" : prefa ?? '#'
    const isGroup = msg.key.remoteJid.endsWith('@g.us')
    const sender = isGroup ? (msg.key.participant ? msg.key.participant : msg.participant) : msg.key.remoteJid
    const isOwner = [ronzz.user.id, ...owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(sender) ? true : false
    const pushname = msg.pushName
    const budy = (type === 'conversation') ? msg.message.conversation : (type === 'extendedTextMessage') ? msg.message.extendedTextMessage.text : ''
    const args = chats.trim().split(/ +/).slice(1);
    const q = args.join(" ");
    const command = chats.replace(prefix, '').trim().split(/ +/).shift().toLowerCase()
    const botNumber = ronzz.user.id.split(':')[0] + '@s.whatsapp.net'
    const groupMetadata = isGroup ? await ronzz.groupMetadata(from) : ''
    const groupName = isGroup ? groupMetadata.subject : ''
    const groupId = isGroup ? groupMetadata.id : ''
    const groupMembers = isGroup ? groupMetadata.participants : ''
    const groupAdmins = isGroup ? getGroupAdmins(groupMembers) : ''
    const isBotGroupAdmins = groupAdmins.includes(botNumber) || false
    const isGroupAdmins = groupAdmins.includes(sender)

    const isImage = (type == 'imageMessage')
    const isQuotedMsg = msg.isQuotedMsg
    const isQuotedImage = isQuotedMsg ? content.includes('imageMessage') ? true : false : false
    const isVideo = (type == 'videoMessage')
    const isQuotedVideo = isQuotedMsg ? content.includes('videoMessage') ? true : false : false
    const isSewa = db.data.sewa[from] ? true : false

    const reply = (teks, options = {}) => { ronzz.sendMessage(from, { text: teks, ...options }, { quoted: msg }) }

    const mentionByTag = type == "extendedTextMessage" && msg.message.extendedTextMessage.contextInfo != null ? msg.message.extendedTextMessage.contextInfo.mentionedJid : []
    const mentionByReply = type == "extendedTextMessage" && msg.message.extendedTextMessage.contextInfo != null ? msg.message.extendedTextMessage.contextInfo.participant || "" : ""
    const mention = typeof (mentionByTag) == 'string' ? [mentionByTag] : mentionByTag
    mention != undefined ? mention.push(mentionByReply) : []

    async function downloadAndSaveMediaMessage(type_file, path_file) {
      if (type_file === 'image') {
        var stream = await downloadContentFromMessage(msg.message.imageMessage || msg.message.extendedTextMessage?.contextInfo.quotedMessage.imageMessage, 'image')
        let buffer = Buffer.from([])
        for await (const chunk of stream) {
          buffer = Buffer.concat([buffer, chunk])
        }
        fs.writeFileSync(path_file, buffer)
        return path_file
      }
      else if (type_file === 'video') {
        var stream = await downloadContentFromMessage(msg.message.videoMessage || msg.message.extendedTextMessage?.contextInfo.quotedMessage.videoMessage, 'video')
        let buffer = Buffer.from([])
        for await (const chunk of stream) {
          buffer = Buffer.concat([buffer, chunk])
        }
        fs.writeFileSync(path_file, buffer)
        return path_file
      } else if (type_file === 'sticker') {
        var stream = await downloadContentFromMessage(msg.message.stickerMessage || msg.message.extendedTextMessage?.contextInfo.quotedMessage.stickerMessage, 'sticker')
        let buffer = Buffer.from([])
        for await (const chunk of stream) {
          buffer = Buffer.concat([buffer, chunk])
        }
        fs.writeFileSync(path_file, buffer)
        return path_file
      } else if (type_file === 'audio') {
        var stream = await downloadContentFromMessage(msg.message.audioMessage || msg.message.extendedTextMessage?.contextInfo.quotedMessage.audioMessage, 'audio')
        let buffer = Buffer.from([])
        for await (const chunk of stream) {
          buffer = Buffer.concat([buffer, chunk])
        }
        fs.writeFileSync(path_file, buffer)
        return path_file
      }
    }

    //Ucapan waktu
    if (dt >= 0) {
      var ucapanWaktu = ('Selamat Malam🌃')
    }
    if (dt >= 4) {
      var ucapanWaktu = ('Selamat Pagi🌄')
    }
    if (dt >= 12) {
      var ucapanWaktu = ('Selamat Siang☀️')
    }
    if (dt >= 16) {
      var ucapanWaktu = ('️ Selamat Sore🌇')
    }
    if (dt >= 23) {
      var ucapanWaktu = ('Selamat Malam🌙')
    }

    if (!db.data.saldo[sender]) db.data.saldo[sender] = 0
    if (!db.data.persentase["untung"]) db.data.persentase["untung"] = untung
    if (!db.data.persentase["pajak"]) db.data.persentase["pajak"] = pajak
    if (!db.data.setting[botNumber]) db.data.setting[botNumber] = {
      autoread: false,
      autoketik: false,
      anticall: true
    }
    if (isGroup && !db.data.chat[from]) db.data.chat[from] = {
      welcome: false,
      antilink: false,
      antilink2: false,
      sDone: "",
      sProses: ""
    }

    function toRupiah(angka) {
      var saldo = '';
      var angkarev = angka.toString().split('').reverse().join('');
      for (var i = 0; i < angkarev.length; i++)
        if (i % 3 == 0) saldo += angkarev.substr(i, 3) + '.';
      return '' + saldo.split('', saldo.length - 1).reverse().join('');
    }

    const formatp = sizeFormatter({
      std: 'JEDEC',
      decimalPlaces: 2,
      keepTrailingZeroes: false,
      render: (literal, symbol) => `${literal} ${symbol}B`,
    })

    expiredCheck(ronzz, msg, groupId)

    if (command === "payqris") {
      if (!db.data.deposit[sender]) {
        db.data.deposit[sender] = {
          ID: require("crypto").randomBytes(5).toString("hex").toUpperCase(),
          session: "amount",
          name: pushname,
          date: moment.tz('Asia/Jakarta').format('DD MMMM YYYY'),
          number: sender,
          payment: "QRIS",
          data: {
            amount_deposit: ""
          }
        }
        reply("Oke kak mau deposit berapa?\n\nContoh: 15000")
      } else {
        reply("Proses deposit kamu masih ada yang belum terselesaikan.\n\nKetik *batal* untuk membatalkan.")
      }
    } else if (command === "paydana") {
      if (!db.data.deposit[sender]) {
        db.data.deposit[sender] = {
          ID: require("crypto").randomBytes(5).toString("hex").toUpperCase(),
          session: "amount",
          name: pushname,
          date: moment.tz('Asia/Jakarta').format('DD MMMM YYYY'),
          number: sender,
          payment: "DANA",
          data: {
            amount_deposit: ""
          }
        }
        reply("Oke kak mau deposit berapa?\n\nContoh: 15000")
      } else {
        reply("Proses deposit kamu masih ada yang belum terselesaikan.\n\nKetik *batal* untuk membatalkan.")
      }
    }

    if (db.data.deposit[sender]) {
      if (!msg.key.fromMe) {
        if (db.data.deposit[sender].session === "amount") {
          if (isNaN(chats)) return reply("Masukan hanya angka ya")
          db.data.deposit[sender].data.amount_deposit = Number(chats);
          db.data.deposit[sender].session = "konfirmasi_deposit";
          let pajakny = (pajak / 100) * db.data.deposit[sender].data.amount_deposit
          reply(`*KONFIRMASI DEPOSIT*\n\n*ID:* ${db.data.deposit[sender].ID}\n*Nomer:* ${db.data.deposit[sender].number.split('@')[0]}\n*Payment:* ${db.data.deposit[sender].payment}\n*Jumlah Deposit:* Rp${toRupiah(db.data.deposit[sender].data.amount_deposit)}\n*Pajak:* Rp${toRupiah(Number(Math.ceil(pajakny)))}\n*Total Pembayaran:* Rp${toRupiah(db.data.deposit[sender].data.amount_deposit + Number(Math.ceil(pajakny)))}\n\n_Deposit akan dibatalkan otomatis apabila terdapat kesalahan input._\n\n_Ketik *lanjut* untuk melanjutkan_\n_Ketik *batal* untuk membatalkan_`)
        } else if (db.data.deposit[sender].session === "konfirmasi_deposit") {
          if (chats.toLowerCase() === "lanjut") {
            if (db.data.deposit[sender].payment === "QRIS") {
              var pyqrs = `*PAYMENT QRIS*
 
*URL:* ${payment.qris.link}
*A/N:* ${payment.qris.an}

_Silahkan transfer ke qris di atas, jika sudah harap kirim bukti foto dengan caption *bukti* untuk di acc oleh Admin._`
              ronzz.sendMessage(from, { image: { url: payment.qris.link }, caption: pyqrs }, { quoted: msg })
            } else if (db.data.deposit[sender].payment === "DANA") {
              var py_dana = `*PAYMENT DANA*
 
*NOMER:* ${payment.dana.nope}
*A/N:* ${payment.dana.an}

_Silahkan transfer dengan nomor yang sudah tertera, jika sudah harap kirim bukti foto dengan caption *bukti* untuk di acc oleh Admin._`
              reply(py_dana)
            }
          } else if (chats.toLowerCase() === "batal") {
            reply(`Baik kak, deposit dengan ID: ${db.data.deposit[sender].ID} dibatalkan`)
            delete db.data.deposit[sender]
          }
        }
      }
    }

    if (isGroup && isAlreadyResponList(from, chats.toLowerCase())) {
      let get_data_respon = getDataResponList(from, chats.toLowerCase())
      if (get_data_respon.isImage === false) {
        ronzz.sendMessage(from, { text: sendResponList(from, chats.toLowerCase()) }, {
          quoted: msg
        })
      } else {
        ronzz.sendMessage(from, { image: { url: get_data_respon.image_url }, caption: get_data_respon.response }, {
          quoted: msg
        })
      }
    }

    if (isAlreadyResponTesti(chats.toLowerCase())) {
      var get_data_respon = getDataResponTesti(chats.toLowerCase())
      ronzz.sendMessage(from, { image: { url: get_data_respon.image_url }, caption: get_data_respon.response }, { quoted: msg })
    }

    if (isGroup && db.data.chat[from].antilink) {
      if (!isBotGroupAdmins) return
      if (chats.match(/(`https:\/\/chat.whatsapp.com\/${ronzz.groupInviteCode(from)}`)/gi)) {
        reply(`*GROUP LINK DETECTOR*\n\nAnda tidak akan dikick oleh bot, karena yang anda kirim adalah link group ini.`)
      } else if (chats.match(/(https:\/\/chat.whatsapp.com)/gi) && !chats.match(/(`https:\/\/chat.whatsapp.com\/${ronzz.groupInviteCode(from)}`)/gi)) {
        if (isOwner) return
        if (isGroupAdmins) return
        await ronzz.sendMessage(from, { delete: msg.key })
        ronzz.sendMessage(from, { text: `*GROUP LINK DETECTOR*\n\nMaaf @${sender.split('@')[0]}, sepertinya kamu mengirimkan link grup, maaf kamu akan di kick.`, mentions: [sender] })
        await sleep(500)
        ronzz.groupParticipantsUpdate(from, [sender], "remove")
      }
    }

    if (isGroup && db.data.chat[from].antilink2) {
      if (!isBotGroupAdmins) return
      if (chats.match(/(https:\/\/chat.whatsapp.com)/gi) && !chats.match(/(`https:\/\/chat.whatsapp.com\/${ronzz.groupInviteCode(from)}`)/gi)) {
        if (isOwner) return
        if (isGroupAdmins) return
        await ronzz.sendMessage(from, { delete: msg.key })
        ronzz.sendMessage(from, { text: `*GROUP LINK DETECTOR*\n\nMaaf @${sender.split('@')[0]}, sepertinya kamu mengirimkan link grup, lain kali jangan kirim link grup yaa.`, mentions: [sender] })
      }
    }

    if (db.data.setting[botNumber].autoread) ronzz.readMessages([msg.key])
    if (db.data.setting[botNumber].autoketik) ronzz.sendPresenceUpdate('composing', from)
    if (msg) console.log('->[\x1b[1;32mCMD\x1b[1;37m]', color(moment(msg.messageTimestamp * 1000).format('DD/MM/YYYY HH:mm:ss'), 'yellow'), color(`${prefix + command} [${args.length}]`), 'from', color(pushname), isGroup ? 'in ' + color(groupName) : '')

    switch (command) {
      case 'menu': {
        let more = String.fromCharCode(8206)
        let readmore = more.repeat(4001)
        let teks = `▬▭▬▭▬ ✦✧✦ ▬▭▬▭▬
                     *MENU*
▬▭▬▭▬ ✦✧✦ ▬▭▬▭▬
*BOT NAME:* ${botName}
*RUNTIME:* ${runtime(process.uptime())}
*OWNER:* @${ownerNomer}

_SILAHKAN PILIH FITUR DIBAWAH_

*CREDIT:* ${ownerName}
▬▭▬▭▬ ✦✧✦ ▬▭▬▭▬
${readmore}
*INFO BOT*

ダ ${prefix}script
ダ ${prefix}creator
ダ ${prefix}runtime
ダ ${prefix}ping
ダ ${prefix}owner

*TOPUP MENU*

ダ ${prefix}deposit
ダ ${prefix}topup
ダ ${prefix}listharga
ダ ${prefix}saldo

*STORE MENU*

ダ ${prefix}list
ダ ${prefix}addlist
ダ ${prefix}dellist
ダ ${prefix}setlist
ダ ${prefix}testi
ダ ${prefix}addtesti
ダ ${prefix}deltesti
ダ ${prefix}settesti
ダ ${prefix}kalkulator
ダ ${prefix}done
ダ ${prefix}setdone
ダ ${prefix}deldone
ダ ${prefix}changedone
ダ ${prefix}proses
ダ ${prefix}setproses
ダ ${prefix}delproses
ダ ${prefix}changeproses

*GROUP MENU*

ダ ${prefix}open
ダ ${prefix}close
ダ ${prefix}kick
ダ ${prefix}promote
ダ ${prefix}demote
ダ ${prefix}delete
ダ ${prefix}revoke
ダ ${prefix}linkgc
ダ ${prefix}hidetag
ダ ${prefix}welcome
ダ ${prefix}antilink
ダ ${prefix}antilink2
ダ ${prefix}ceksewa

*OWNER MENU*

ダ ${prefix}addsewa
ダ ${prefix}delsewa
ダ ${prefix}block
ダ ${prefix}unblock
ダ ${prefix}kirim
ダ ${prefix}tarik
ダ ${prefix}setprofit
ダ ${prefix}cekip
ダ ${prefix}ceksaldo
ダ ${prefix}listsewa`
        ronzz.sendMessage(from, { text: teks, mentions: [ownerNomer + '@s.whatsapp.net'] }, { quoted: msg })
      }
        break

      case 'deposit': case 'depo': {
        ronzz.sendMessage(from, { text: `Hai *@${sender.split('@')[0]}*\nIngin melakukan deposit? silahkan pilih payment yang tersedia\n\n*PAYMENT:* QRIS\n*SISTEM:* Manual\n*ID:* payqris\n\n*PAYMENT:* DANA\n*SISTEM:* Manual\n*ID:* paydana\n\n_Ingin pilih payment? ketik id payment_\nContoh : *payqris*`, mentions: [sender] })
      }
        break

      case 'bukti': {
        if (!db.data.deposit[sender]) return ronzz.sendMessage(from, { text: `Maaf *@${sender.split('@')[0]}* sepertinya kamu belum pernah melakukan deposit`, mentions: [sender] }, { quoted: msg })
        if (!isImage && !isQuotedImage) return reply(`Kirim gambar dengan caption *${prefix}bukti* atau reply gambar yang sudah dikirim dengan caption *${prefix}bukti*`)
        let media = await downloadAndSaveMediaMessage('image', `./options/sticker/${sender.split('@')[0]}.jpg`)
        let pajakny = (db.data.persentase["pajak"] / 100) * db.data.deposit[sender].data.amount_deposit
        let caption_bukti = `*DEPOSIT USER*
*ID:* ${db.data.deposit[sender].ID}
*Nomer:* @${db.data.deposit[sender].number.split('@')[0]}
*Payment:* ${db.data.deposit[sender].payment}
*Tanggal:* ${db.data.deposit[sender].date}
*Jumlah Deposit:* Rp${toRupiah(db.data.deposit[sender].data.amount_deposit)}
*Pajak:* Rp${toRupiah(Number(Math.ceil(pajakny)))}
*Total Bayar:* Rp${toRupiah(db.data.deposit[sender].data.amount_deposit + Number(Math.ceil(pajakny)))}

Ada yang deposit nih kak, coba dicek saldonya,
Jika sudah masuk konfirmasi dengan cara ketik *#accdepo*
Jika belum masuk batalkan dengan cara ketik *#rejectdepo*`
        await ronzz.sendMessage(`${ownerNomer}@s.whatsapp.net`, { image: fs.readFileSync(media), caption: caption_bukti, mentions: [db.data.deposit[sender].number], title: 'BUKTI PEMBAYARAN' })
        await reply(`Mohon tunggu yaa kak, sampai di acc oleh owner`)
        fs.unlinkSync(media)
      }
        break

      case 'accdepo': {
        if (!isOwner) return
        if (!q) return reply(`Contoh: ${prefix + command} 628xxx`)
        let orang = q.split(",")[0].replace(/[^0-9]/g, '')
        let pajakny = (db.data.persentase["pajak"] / 100) * db.data.deposit[orang + "@s.whatsapp.net"].data.amount_deposit
        db.data.saldo[orang + "@s.whatsapp.net"] += Number(db.data.deposit[orang + "@s.whatsapp.net"].data.amount_deposit)
        var text_sukses = `*DEPOSIT SUKSES*
*ID:* ${db.data.deposit[orang + "@s.whatsapp.net"].ID}
*Nomer:* @${db.data.deposit[orang + "@s.whatsapp.net"].number.split('@')[0]}
*Payment:* ${db.data.deposit[orang + "@s.whatsapp.net"].payment}
*Tanggal:* ${db.data.deposit[orang + "@s.whatsapp.net"].date.split(' ')[0]}
*Jumlah Deposit:* Rp${toRupiah(db.data.deposit[orang + "@s.whatsapp.net"].data.amount_deposit)}
*Pajak:* Rp${toRupiah(Number(Math.ceil(pajakny)))}
*Total Bayar:* Rp${toRupiah(db.data.deposit[orang + "@s.whatsapp.net"].data.amount_deposit + Number(Math.ceil(pajakny)))}`
        await reply(text_sukses)
        await ronzz.sendMessage(db.data.deposit[orang + "@s.whatsapp.net"].number, { text: `${text_sukses}\n\n_Deposit kamu telah dikonfirmasi oleh admin, silahkan cek saldo dengan cara ketik *#saldo*_` })
      }
        break

      case 'rejectdepo': {
        if (!isOwner) return
        if (!q) return reply(`Contoh: ${prefix + command} 628xxx`)
        let orang = q.split(",")[0].replace(/[^0-9]/g, '')
        await reply(`Sukses reject deposit dengan ID: ${db.data.deposit[orang + "@s.whatsapp.net"].ID}`)
        await ronzz.sendMessage(db.data.deposit[orang + "@s.whatsapp.net"].number, { text: `Maaf deposit dengan ID: *${db.data.deposit[orang + "@s.whatsapp.net"].ID}* ditolak, Jika ada kendala hubungin owner bot.\nwa.me/${ownerNomer}` })
      }
        break

      case 'saldo': {
        reply(`*CHECK YOUR INFO*

 _• *Name:* ${pushname}_
 _• *Nomer:* ${sender.split('@')[0]}_
 _• *Saldo:* Rp${toRupiah(db.data.saldo[sender])}_

*Note :*
_Saldo hanya bisa untuk topup_
_Tidak bisa ditarik atau transfer_!`)
      }
        break

      case 'kirim': {
        if (!isOwner) return reply(mess.owner)
        if (!q) return reply(`Contoh: ${prefix + command} 628xx,20000`)
        if (!q.split(",")[0]) return reply(`Contoh: ${prefix + command} 628xx,20000`)
        if (!q.split(",")[1]) return reply(`Contoh: ${prefix + command} 628xx,20000`)
        let nomorNya = q.split(",")[0].replace(/[^0-9]/g, '') + "@s.whatsapp.net"
        db.data.saldo[nomorNya] += Number(q.split(",")[1])
        await sleep(50)
        ronzz.sendMessage(from, { text: `*SALDO USER*\nID: ${nomorNya.split('@')[0]}\nNomer: @${nomorNya.split('@')[0]}\nSaldo: Rp${toRupiah(db.data.saldo[nomorNya])}`, mentions: [nomorNya] }, { quoted: msg })
      }
        break

      case 'tarik': {
        if (!isOwner) return reply(mess.owner)
        if (!q) return reply(`Contoh: ${prefix + command} 628xx,20000`)
        if (!q.split(",")[0]) return reply(`Contoh: ${prefix + command} 628xx,20000`)
        if (!q.split(",")[1]) return reply(`Contoh: ${prefix + command} 628xx,20000`)
        let nomorNya = q.split(",")[0].replace(/[^0-9]/g, '') + "@s.whatsapp.net"
        if (db.data.saldo[nomorNya] == 0) return reply("Dia belum terdaftar di database saldo.")
        if (db.data.saldo[nomorNya] < q.split(",")[1] && db.data.saldo[nomorNya] !== 0) return reply(`Dia saldonya ${db.data.saldo[nomorNya]}, jadi jangan melebihi ${db.data.saldo[nomorNya]} yah kak??`)
        db.data.saldo[nomorNya] -= Number(q.split(",")[1])
        await sleep(50)
        ronzz.sendMessage(from, { text: `*SALDO USER*\nID: ${nomorNya.split('@')[0]}\nNomer: @${nomorNya.split('@')[0]}\nSaldo: Rp${toRupiah(db.data.saldo[nomorNya])}`, mentions: [nomorNya] }, { quoted: msg })
      }
        break

      case 'topup': {
        if (db.data.saldo[sender] < 1) return reply(`Maaf *${pushname}*, sepertinya saldo kamu Rp${toRupiah(db.data.saldo[sender])}, silahkan melakukan deposit terlebih dahulu sebelum melakukan topup.`)
        if (!db.data.topup[sender]) {
          if (!q) return reply(`*FORMAT TOPUP*\n\n*FORMAT ML*\n${prefix + command} kodeproduk,id(zone)\nContoh: ${prefix + command} ML1500,123456789(1234)\n\n*FORMAT LAINNYA*\n${prefix + command} kodeproduk,no/id\n\nUntuk mendapatkan kode produk ketik *${prefix}listharga*`)
          if (!q.split(",")[1]) return reply(`*FORMAT TOPUP*\n\n*FORMAT ML*\n${prefix + command} kodeproduk,id(zone)\nContoh: ${prefix + command} ML1500,123456789(1234)\n\n*FORMAT LAINNYA*\n${prefix + command} kodeproduk,no/id\n\nUntuk mendapatkan kode produk ketik *${prefix}listharga*`)
          if (q.split(",")[0].startsWith("DML") && !q.split("(")[1]) return reply(`*FORMAT TOPUP*\n\n*FORMAT ML*\n${prefix + command} kodeproduk,id(zone)\nContoh: ${prefix + command} ML1500,123456789(1234)\n\n*FORMAT LAINNYA*\n${prefix + command} kodeproduk,no/id\n\nUntuk mendapatkan kode produk ketik *${prefix}listharga*`)
          axios.get(okeUrl)
            .then(response => response.data)
            .then(async ress => {
              let listproduk = ress.find(i => i.kode == q.split(",")[0])
              if (!listproduk) return reply(`Untuk kode produk *${q.split(",")[0]}* tidak ada`)
              let kntungan = (db.data.persentase["untung"] / 100) * Number(listproduk.harga)
              if (db.data.saldo[sender] < Number(listproduk.harga.replace(/[^0-9]/g, '')) + Number(Math.ceil(kntungan))) return reply(`Maaf *${pushname},* sepertinya saldo anda kurang dari Rp${toRupiah(Number(listproduk.harga.replace(/[^0-9]/g, '')) + Number(Math.ceil(kntungan)))}, silahkan melakukan deposit terlebih dahulu`)
              axios.get(`https://b2b.okeconnect.com/trx-v2?product=${q.split(",")[0]}&dest=${q.split(",")[1].replace(/[^0-9]/g, "")}&refID=${require("crypto").randomBytes(5).toString("hex").toUpperCase()}&memberID=${memberId}&pin=${pin}&password=${pw}`)
                .then(response => response.data)
                .then(async res => {
                  if (res.status.includes('GAGAL')) return reply(res.message)
                  let keuntungan = (db.data.persentase["untung"] / 100) * res.price
                  db.data.topup[sender] = {
                    number: sender,
                    data: {
                      id: res.refid,
                      idgame: q.split("(")[1] ? q.split(",")[1].split("(")[0] : q.split(",")[1],
                      zone: q.split("(")[1] ? q.split("(")[1].split(")")[0] : "",
                      code: q.split(",")[0],
                      price: Number(res.price) + Number(Math.ceil(keuntungan)),
                      time: res.time
                    }
                  }
                  reply('Transaksi diproses...')
                  let status = res.status
                  while (status !== 'SUKSES') {
                    await sleep(1000)
                    let responsed = await axios.get(`https://b2b.okeconnect.com/trx-v2?product=${db.data.topup[sender].data.code}&dest=${db.data.topup[sender].data.idgame + db.data.topup[sender].data.zone}&refID=${db.data.topup[sender].data.id}&memberID=${memberId}&pin=${pin}&password=${pw}`)
                    let responses = await responsed.data
                    status = responses.status
                    if (responses.status == "GAGAL") {
                      reply(`Pesanan dibatalkan!\nAlasan: ${responses.message}`)
                      delete db.data.topup[sender]
                      break
                    }
                    if (responses.status == "SUKSES") {
                      reply(`*TOPUP SUKSES*\n*Status:* success\n*ID Order:* ${responses.refid}\n*Jam:* ${responses.time} WIB\n*Nomor Tujuan:* ${db.data.topup[sender].data.idgame + db.data.topup[sender].data.zone}\n*Price:* Rp${toRupiah(db.data.topup[sender].data.price)}\n\n*SN:*\n${responses.sn}\n\n_Terimakasih kak sudah order.️_`)
                      db.data.saldo["sender"] -= Number(db.data.topup[sender].data.price)
                      delete db.data.topup[sender]
                      break
                    }
                  }
                })
            })
        } else {
          reply(`Kamu sedang melakukan topup, mohong tunggu sampai proses topup selesai.`)
        }
      }
        break

      case 'listharga': {
        let teks = `Silahkan pilih salah satu menu
dengan mengetik pilihan nomor
dibawah ini (contoh: *1*)

*VOUCHER GAME*
KETIK *1* LIST HARGA TOPUP ML
KETIK *2* LIST HARGA TOPUP FF
KETIK *3* LIST HARGA TOPUP PUBG

*TOKEN LISTRIK*
KETIK *4* LIST HARGA TOKEN PLN

*TOPUP SALDO*
KETIK *5* LIST HARGA SALDO DANA
KETIK *6* LIST HARGA SALDO GOPAY
KETIK *7* LIST HARGA SALDO OVO
KETIK *8* LIST HARGA SALDO SHOPEEPAY
KETIK *9* LIST HARGA SALDO LINKAJA

*KUOTA INTERNET*
KETIK *10* LIST HARGA KUOTA SMARTFREN
KETIK *11* LIST HARGA KUOTA TELKOMSEL
KETIK *12* LIST HARGA KUOTA AXIS
KETIK *13* LIST HARGA KUOTA INDOSAT
KETIK *14* LIST HARGA KUOTA THREE

*PULSA TRANSFER*
KETIK *15* LIST HARGA PULSA SMARTFREN
KETIK *16* LIST HARGA PULSA TELKOMSEL
KETIK *17* LIST HARGA PULSA AXIS
KETIK *18* LIST HARGA PULSA INDOSAT
KETIK *19* LIST HARGA PULSA THREE`
        reply(teks)
      }
        break

      case '1': {
        axios.get(okeUrl)
          .then(response => response.data)
          .then(res => {
            var regeXcomp = (a, b) => {
              var aPrice = Number(a.harga.replace(/[^0-9.-]+/g, ""));
              var bPrice = Number(b.harga.replace(/[^0-9.-]+/g, ""));
              return aPrice - bPrice
            }
            res.sort(regeXcomp)
            let teks = `*LIST HARGA TOPUP ML*\n\nIngin melakukan topup? ketik *${prefix}topup*\n\n`
            for (let i of res) {
              if (i.kode.startsWith('DML')) {
                let persen = (db.data.persentase["untung"] / 100) * i.harga
                teks += `*Kode:* ${i.kode}\n*Nama:* ${i.keterangan.includes('H2H') ? i.keterangan.replace('Customer H2H ', '') : i.keterangan.replace('Customer ', '')}\n*Harga:* Rp${toRupiah(Number(i.harga) + Number(Math.ceil(persen)))}\n*Status:* ${i.status == "1" ? "✅" : "❎"}\n\n`
              }
            }
            reply(teks)
          })
      }
        break

      case '2': {
        axios.get(okeUrl)
          .then(response => response.data)
          .then(res => {
            var regeXcomp = (a, b) => {
              var aPrice = Number(a.harga.replace(/[^0-9.-]+/g, ""));
              var bPrice = Number(b.harga.replace(/[^0-9.-]+/g, ""));
              return aPrice - bPrice
            }
            res.sort(regeXcomp)
            let teks = `*LIST HARGA TOPUP FF*\n\nIngin melakukan topup? ketik *${prefix}topup*\n\n`
            for (let i of res) {
              if (i.kode.startsWith('FF')) {
                let persen = (db.data.persentase["untung"] / 100) * i.harga
                teks += `*Kode:* ${i.kode}\n*Nama:* ${i.keterangan.includes('H2H') ? i.keterangan.replace('Customer H2H ', '') : i.keterangan.replace('Customer ', '')}\n*Harga:* Rp${toRupiah(Number(i.harga) + Number(Math.ceil(persen)))}\n*Status:* ${i.status == "1" ? "✅" : "❎"}\n\n`
              }
            }
            reply(teks)
          })
      }
        break

      case '3': {
        axios.get(okeUrl)
          .then(response => response.data)
          .then(res => {
            var regeXcomp = (a, b) => {
              var aPrice = Number(a.harga.replace(/[^0-9.-]+/g, ""));
              var bPrice = Number(b.harga.replace(/[^0-9.-]+/g, ""));
              return aPrice - bPrice
            }
            res.sort(regeXcomp)
            let teks = `*LIST HARGA TOPUP PUBG*\n\nIngin melakukan topup? ketik *${prefix}topup*\n\n`
            for (let i of res) {
              if (i.kode.startsWith('PUBG')) {
                let persen = (db.data.persentase["untung"] / 100) * i.harga
                teks += `*Kode:* ${i.kode}\n*Nama:* ${i.keterangan.includes('H2H') ? i.keterangan.replace('Customer H2H ', '') : i.keterangan.replace('Customer ', '')}\n*Harga:* Rp${toRupiah(Number(i.harga) + Number(Math.ceil(persen)))}\n*Status:* ${i.status == "1" ? "✅" : "❎"}\n\n`
              }
            }
            reply(teks)
          })
      }
        break

      case '4': {
        axios.get(okeUrl)
          .then(response => response.data)
          .then(res => {
            var regeXcomp = (a, b) => {
              var aPrice = Number(a.harga.replace(/[^0-9.-]+/g, ""));
              var bPrice = Number(b.harga.replace(/[^0-9.-]+/g, ""));
              return aPrice - bPrice
            }
            res.sort(regeXcomp)
            let teks = `*LIST HARGA TOKEN PLN*\n\nIngin melakukan topup? ketik *${prefix}topup*\n\n`
            for (let i of res) {
              if (i.kode.startsWith('PLN')) {
                let persen = (db.data.persentase["untung"] / 100) * i.harga
                teks += `*Kode:* ${i.kode}\n*Nama:* ${i.keterangan.includes('H2H') ? i.keterangan.replace('H2H ', '') : i.keterangan}\n*Harga:* Rp${toRupiah(Number(i.harga) + Number(Math.ceil(persen)))}\n*Status:* ${i.status == "1" ? "✅" : "❎"}\n\n`
              }
            }
            reply(teks)
          })
      }
        break

      case '5': {
        axios.get(okeUrl)
          .then(response => response.data)
          .then(res => {
            var regeXcomp = (a, b) => {
              var aPrice = Number(a.harga.replace(/[^0-9.-]+/g, ""));
              var bPrice = Number(b.harga.replace(/[^0-9.-]+/g, ""));
              return aPrice - bPrice
            }
            res.sort(regeXcomp)
            let teks = `*LIST HARGA SALDO DANA*\n\nIngin melakukan topup? ketik *${prefix}topup*\n\n`
            for (let i of res) {
              if (i.kode.startsWith('D') && i.kategori == "DOMPET DIGITAL") {
                let persen = (db.data.persentase["untung"] / 100) * i.harga
                teks += `*Kode:* ${i.kode}\n*Nama:* ${i.keterangan.includes('H2H') ? i.keterangan.replace('H2H ', '') : i.keterangan}\n*Harga:* Rp${toRupiah(Number(i.harga) + Number(Math.ceil(persen)))}\n*Status:* ${i.status == "1" ? "✅" : "❎"}\n\n`
              }
            }
            reply(teks)
          })
      }
        break

      case '6': {
        axios.get(okeUrl)
          .then(response => response.data)
          .then(res => {
            var regeXcomp = (a, b) => {
              var aPrice = Number(a.harga.replace(/[^0-9.-]+/g, ""));
              var bPrice = Number(b.harga.replace(/[^0-9.-]+/g, ""));
              return aPrice - bPrice
            }
            res.sort(regeXcomp)
            let teks = `*LIST HARGA SALDO GOPAY*\n\nIngin melakukan topup? ketik *${prefix}topup*\n\n`
            for (let i of res) {
              if (i.kode.startsWith('GJK')) {
                let persen = (db.data.persentase["untung"] / 100) * i.harga
                teks += `*Kode:* ${i.kode}\n*Nama:* ${i.keterangan.includes('H2H') ? i.keterangan.replace('Customer H2H ', '') : i.keterangan.replace('Customer ', '')}\n*Harga:* Rp${toRupiah(Number(i.harga) + Number(Math.ceil(persen)))}\n*Status:* ${i.status == "1" ? "✅" : "❎"}\n\n`
              }
            }
            reply(teks)
          })
      }
        break

      case '7': {
        axios.get(okeUrl)
          .then(response => response.data)
          .then(res => {
            var regeXcomp = (a, b) => {
              var aPrice = Number(a.harga.replace(/[^0-9.-]+/g, ""));
              var bPrice = Number(b.harga.replace(/[^0-9.-]+/g, ""));
              return aPrice - bPrice
            }
            res.sort(regeXcomp)
            let teks = `*LIST HARGA SALDO OVO*\n\nIngin melakukan topup? ketik *${prefix}topup*\n\n`
            for (let i of res) {
              if (i.kode.startsWith('OVO')) {
                let persen = (db.data.persentase["untung"] / 100) * i.harga
                teks += `*Kode:* ${i.kode}\n*Nama:* ${i.keterangan.includes('H2H') ? i.keterangan.replace('H2H ', '') : i.keterangan}\n*Harga:* Rp${toRupiah(Number(i.harga) + Number(Math.ceil(persen)))}\n*Status:* ${i.status == "1" ? "✅" : "❎"}\n\n`
              }
            }
            reply(teks)
          })
      }
        break

      case '8': {
        axios.get(okeUrl)
          .then(response => response.data)
          .then(res => {
            var regeXcomp = (a, b) => {
              var aPrice = Number(a.harga.replace(/[^0-9.-]+/g, ""));
              var bPrice = Number(b.harga.replace(/[^0-9.-]+/g, ""));
              return aPrice - bPrice
            }
            res.sort(regeXcomp)
            let teks = `*LIST HARGA SALDO SHOPEEPAY*\n\nIngin melakukan topup? ketik *${prefix}topup*\n\n`
            for (let i of res) {
              if (i.kode.startsWith('SHOPE')) {
                let persen = (db.data.persentase["untung"] / 100) * i.harga
                teks += `*Kode:* ${i.kode}\n*Nama:* ${i.keterangan.includes('H2H') ? i.keterangan.replace('H2H ', '') : i.keterangan}\n*Harga:* Rp${toRupiah(Number(i.harga) + Number(Math.ceil(persen)))}\n*Status:* ${i.status == "1" ? "✅" : "❎"}\n\n`
              }
            }
            reply(teks)
          })
      }
        break

      case '9': {
        axios.get(okeUrl)
          .then(response => response.data)
          .then(res => {
            var regeXcomp = (a, b) => {
              var aPrice = Number(a.harga.replace(/[^0-9.-]+/g, ""));
              var bPrice = Number(b.harga.replace(/[^0-9.-]+/g, ""));
              return aPrice - bPrice
            }
            res.sort(regeXcomp)
            let teks = `*LIST HARGA SALDO LINKAJA*\n\nIngin melakukan topup? ketik *${prefix}topup*\n\n`
            for (let i of res) {
              if (i.kode.startsWith('LINK')) {
                let persen = (db.data.persentase["untung"] / 100) * i.harga
                teks += `*Kode:* ${i.kode}\n*Nama:* ${i.keterangan.includes('H2H') ? i.keterangan.replace('H2H ', '') : i.keterangan}\n*Harga:* Rp${toRupiah(Number(i.harga) + Number(Math.ceil(persen)))}\n*Status:* ${i.status == "1" ? "✅" : "❎"}\n\n`
              }
            }
            reply(teks)
          })
      }
        break

      case '10': {
        axios.get(okeUrl)
          .then(response => response.data)
          .then(res => {
            var regeXcomp = (a, b) => {
              var aPrice = Number(a.harga.replace(/[^0-9.-]+/g, ""));
              var bPrice = Number(b.harga.replace(/[^0-9.-]+/g, ""));
              return aPrice - bPrice
            }
            res.sort(regeXcomp)
            let teks = `*LIST HARGA KUOTA SMARTFREN*\n\nIngin melakukan topup? ketik *${prefix}topup*\n\n`
            for (let i of res) {
              if (i.kategori.includes('KUOTA SMARTFREN')) {
                let persen = (db.data.persentase["untung"] / 100) * i.harga
                teks += `*Kode:* ${i.kode}\n*Nama:* ${i.keterangan.includes('H2H') ? i.keterangan.replace('H2H ', '') : i.keterangan}\n*Harga:* Rp${toRupiah(Number(i.harga) + Number(Math.ceil(persen)))}\n*Status:* ${i.status == "1" ? "✅" : "❎"}\n\n`
              }
            }
            reply(teks)
          })
      }
        break

      case '11': {
        axios.get(okeUrl)
          .then(response => response.data)
          .then(res => {
            var regeXcomp = (a, b) => {
              var aPrice = Number(a.harga.replace(/[^0-9.-]+/g, ""));
              var bPrice = Number(b.harga.replace(/[^0-9.-]+/g, ""));
              return aPrice - bPrice
            }
            res.sort(regeXcomp)
            let teks = `*LIST HARGA KUOTA TELKOMSEL*\n\nIngin melakukan topup? ketik *${prefix}topup*\n\n`
            for (let i of res) {
              if (i.kategori.includes('KUOTA TELKOMSEL')) {
                let persen = (db.data.persentase["untung"] / 100) * i.harga
                teks += `*Kode:* ${i.kode}\n*Nama:* ${i.keterangan.includes('H2H') ? i.keterangan.replace('H2H ', '') : i.keterangan}\n*Harga:* Rp${toRupiah(Number(i.harga) + Number(Math.ceil(persen)))}\n*Status:* ${i.status == "1" ? "✅" : "❎"}\n\n`
              }
            }
            reply(teks)
          })
      }
        break

      case '12': {
        axios.get(okeUrl)
          .then(response => response.data)
          .then(res => {
            var regeXcomp = (a, b) => {
              var aPrice = Number(a.harga.replace(/[^0-9.-]+/g, ""));
              var bPrice = Number(b.harga.replace(/[^0-9.-]+/g, ""));
              return aPrice - bPrice
            }
            res.sort(regeXcomp)
            let teks = `*LIST HARGA KUOTA AXIS*\n\nIngin melakukan topup? ketik *${prefix}topup*\n\n`
            for (let i of res) {
              if (i.kategori.includes('KUOTA AXIS')) {
                let persen = (db.data.persentase["untung"] / 100) * i.harga
                teks += `*Kode:* ${i.kode}\n*Nama:* ${i.keterangan.includes('H2H') ? i.keterangan.replace('H2H ', '') : i.keterangan}\n*Harga:* Rp${toRupiah(Number(i.harga) + Number(Math.ceil(persen)))}\n*Status:* ${i.status == "1" ? "✅" : "❎"}\n\n`
              }
            }
            reply(teks)
          })
      }
        break

      case '13': {
        axios.get(okeUrl)
          .then(response => response.data)
          .then(res => {
            var regeXcomp = (a, b) => {
              var aPrice = Number(a.harga.replace(/[^0-9.-]+/g, ""));
              var bPrice = Number(b.harga.replace(/[^0-9.-]+/g, ""));
              return aPrice - bPrice
            }
            res.sort(regeXcomp)
            let teks = `*LIST HARGA KUOTA INDOSAT*\n\nIngin melakukan topup? ketik *${prefix}topup*\n\n`
            for (let i of res) {
              if (i.kategori.includes('KUOTA INDOSAT')) {
                let persen = (db.data.persentase["untung"] / 100) * i.harga
                teks += `*Kode:* ${i.kode}\n*Nama:* ${i.keterangan.includes('H2H') ? i.keterangan.replace('H2H ', '') : i.keterangan}\n*Harga:* Rp${toRupiah(Number(i.harga) + Number(Math.ceil(persen)))}\n*Status:* ${i.status == "1" ? "✅" : "❎"}\n\n`
              }
            }
            reply(teks)
          })
      }
        break

      case '14': {
        axios.get(okeUrl)
          .then(response => response.data)
          .then(res => {
            var regeXcomp = (a, b) => {
              var aPrice = Number(a.harga.replace(/[^0-9.-]+/g, ""));
              var bPrice = Number(b.harga.replace(/[^0-9.-]+/g, ""));
              return aPrice - bPrice
            }
            res.sort(regeXcomp)
            let teks = `*LIST HARGA KUOTA THREE*\n\nIngin melakukan topup? ketik *${prefix}topup*\n\n`
            for (let i of res) {
              if (i.kategori.includes('KUOTA TRI')) {
                let persen = (db.data.persentase["untung"] / 100) * i.harga
                teks += `*Kode:* ${i.kode}\n*Nama:* ${i.keterangan.includes('H2H') ? i.keterangan.replace('H2H ', '') : i.keterangan}\n*Harga:* Rp${toRupiah(Number(i.harga) + Number(Math.ceil(persen)))}\n*Status:* ${i.status == "1" ? "✅" : "❎"}\n\n`
              }
            }
            reply(teks)
          })
      }
        break

      case '15': {
        axios.get(okeUrl)
          .then(response => response.data)
          .then(res => {
            var regeXcomp = (a, b) => {
              var aPrice = Number(a.harga.replace(/[^0-9.-]+/g, ""));
              var bPrice = Number(b.harga.replace(/[^0-9.-]+/g, ""));
              return aPrice - bPrice
            }
            res.sort(regeXcomp)
            let teks = `*LIST HARGA PULSA SMARTFREN*\n\nIngin melakukan topup? ketik *${prefix}topup*\n\n`
            for (let i of res) {
              if (i.kategori.includes('PULSA') && !i.kategori.includes('PULSA TRANSFER') && i.produk.includes('Smartfren')) {
                let persen = (db.data.persentase["untung"] / 100) * i.harga
                teks += `*Kode:* ${i.kode}\n*Nama:* ${i.keterangan.includes('H2H') ? i.keterangan.replace('H2H ', '') : i.keterangan}\n*Harga:* Rp${toRupiah(Number(i.harga) + Number(Math.ceil(persen)))}\n*Status:* ${i.status == "1" ? "✅" : "❎"}\n\n`
              }
            }
            reply(teks)
          })
      }
        break

      case '16': {
        axios.get(okeUrl)
          .then(response => response.data)
          .then(res => {
            var regeXcomp = (a, b) => {
              var aPrice = Number(a.harga.replace(/[^0-9.-]+/g, ""));
              var bPrice = Number(b.harga.replace(/[^0-9.-]+/g, ""));
              return aPrice - bPrice
            }
            res.sort(regeXcomp)
            let teks = `*LIST HARGA PULSA TELKOMSEL*\n\nIngin melakukan topup? ketik *${prefix}topup*\n\n`
            for (let i of res) {
              if (i.kategori.includes('PULSA') && !i.kategori.includes('PULSA TRANSFER') && i.produk.includes('Telkomsel')) {
                let persen = (db.data.persentase["untung"] / 100) * i.harga
                teks += `*Kode:* ${i.kode}\n*Nama:* ${i.keterangan.includes('H2H') ? i.keterangan.replace('H2H ', '') : i.keterangan}\n*Harga:* Rp${toRupiah(Number(i.harga) + Number(Math.ceil(persen)))}\n*Status:* ${i.status == "1" ? "✅" : "❎"}\n\n`
              }
            }
            reply(teks)
          })
      }
        break

      case '17': {
        axios.get(okeUrl)
          .then(response => response.data)
          .then(res => {
            var regeXcomp = (a, b) => {
              var aPrice = Number(a.harga.replace(/[^0-9.-]+/g, ""));
              var bPrice = Number(b.harga.replace(/[^0-9.-]+/g, ""));
              return aPrice - bPrice
            }
            res.sort(regeXcomp)
            let teks = `*LIST HARGA PULSA AXIS*\n\nIngin melakukan topup? ketik *${prefix}topup*\n\n`
            for (let i of res) {
              if (i.kategori.includes('PULSA') && !i.kategori.includes('PULSA TRANSFER') && i.produk.includes('Axis')) {
                let persen = (db.data.persentase["untung"] / 100) * i.harga
                teks += `*Kode:* ${i.kode}\n*Nama:* ${i.keterangan.includes('H2H') ? i.keterangan.replace('H2H ', '') : i.keterangan}\n*Harga:* Rp${toRupiah(Number(i.harga) + Number(Math.ceil(persen)))}\n*Status:* ${i.status == "1" ? "✅" : "❎"}\n\n`
              }
            }
            reply(teks)
          })
      }
        break

      case '18': {
        axios.get(okeUrl)
          .then(response => response.data)
          .then(res => {
            var regeXcomp = (a, b) => {
              var aPrice = Number(a.harga.replace(/[^0-9.-]+/g, ""));
              var bPrice = Number(b.harga.replace(/[^0-9.-]+/g, ""));
              return aPrice - bPrice
            }
            res.sort(regeXcomp)
            let teks = `*LIST HARGA PULSA INDOSAT*\n\nIngin melakukan topup? ketik *${prefix}topup*\n\n`
            for (let i of res) {
              if (i.kategori.includes('PULSA') && !i.kategori.includes('PULSA TRANSFER') && i.produk.includes('Indosat')) {
                let persen = (db.data.persentase["untung"] / 100) * i.harga
                teks += `*Kode:* ${i.kode}\n*Nama:* ${i.keterangan.includes('H2H') ? i.keterangan.replace('H2H ', '') : i.keterangan}\n*Harga:* Rp${toRupiah(Number(i.harga) + Number(Math.ceil(persen)))}\n*Status:* ${i.status == "1" ? "✅" : "❎"}\n\n`
              }
            }
            reply(teks)
          })
      }
        break

      case '19': {
        axios.get(okeUrl)
          .then(response => response.data)
          .then(res => {
            var regeXcomp = (a, b) => {
              var aPrice = Number(a.harga.replace(/[^0-9.-]+/g, ""));
              var bPrice = Number(b.harga.replace(/[^0-9.-]+/g, ""));
              return aPrice - bPrice
            }
            res.sort(regeXcomp)
            let teks = `*LIST HARGA PULSA THREE*\n\nIngin melakukan topup? ketik *${prefix}topup*\n\n`
            for (let i of res) {
              if (i.kategori.includes('PULSA') && !i.kategori.includes('PULSA TRANSFER') && i.produk.includes('Three')) {
                let persen = (db.data.persentase["untung"] / 100) * i.harga
                teks += `*Kode:* ${i.kode}\n*Nama:* ${i.keterangan.includes('H2H') ? i.keterangan.replace('H2H ', '') : i.keterangan}\n*Harga:* Rp${toRupiah(Number(i.harga) + Number(Math.ceil(persen)))}\n*Status:* ${i.status == "1" ? "✅" : "❎"}\n\n`
              }
            }
            reply(teks)
          })
      }
        break

      case 'setprofit': {
        if (!isOwner) return reply(mess.owner)
        if (!q) return reply(`Contoh: ${prefix + command} 6%`)
        if (q.replace(/[^0-9]/g, '') < 1) return reply('Minimal keuntungan 1%')
        if (q.replace(/[^0-9]/g, '') > 99) return reply('Maksimal keuntungan 99%')
        db.data.persentase["untung"] = q.replace(/[^0-9]/g, '')
        await reply(`Keuntungan telah diset menjadi ${q.replace(/[^0-9]/g, '')}%`)
      }
        break

      case 'ceksaldo': {
        if (!isOwner) return reply(mess.owner)
        axios.get(`https://b2b.okeconnect.com/trx-v2/balance?memberID=${memberId}&pin=${pin}&password=${pw}`)
          .then(response => response.data)
          .then(res => {
            if (res.status.includes('GAGAL')) return reply('Silahkan sambungkan ip (' + res.message.replace(/[^0-9.]+/g, '') + ') tersebut ke provider')
            reply(`*SALDO ORDER KUOTA*\n\n*Sisa Saldo:* Rp${toRupiah(res.message.replace(/[^0-9]+/g, ''))}`)
          })
      }
        break

      case 'cekip': {
        if (!isOwner) return reply(mess.owner)
        axios.get(`https://b2b.okeconnect.com/trx-v2/balance?memberID=${memberId}&pin=${pin}&password=${pw}`)
          .then(response => response.data)
          .then(res => {
            if (res.status.includes('GAGAL')) return reply('Silahkan sambungkan ip (' + res.message.replace(/[^0-9.]+/g, '') + ') tersebut ke provider')
            reply('IP sudah tersambung ke server.')
          })
      }
        break

      case 'sticker': case 's': case 'stiker': {
        if (isImage || isQuotedImage) {
          let media = await downloadAndSaveMediaMessage('image', `./options/sticker/${tanggal}.jpg`)
          reply(mess.wait)
          ronzz.sendImageAsSticker(from, media, msg, { packname: `${packname}`, author: `${author}` })
          fs.unlinkSync(media)
        } else if (isVideo || isQuotedVideo) {
          let media = await downloadAndSaveMediaMessage('video', `./options/sticker/${tanggal}.mp4`)
          reply(mess.wait)
          ronzz.sendVideoAsSticker(from, media, msg, { packname: `${packname}`, author: `${author}` })
          fs.unlinkSync(media)
        } else {
          reply(`Kirim/reply gambar/vidio dengan caption *${prefix + command}*`)
        }
      }
        break

      case 'addsewa': {
        if (!isOwner) return reply(mess.owner)
        if (!isGroup) return reply(mess.group)
        if (!q) return reply(`Ex: ${prefix + command} hari\n\nContoh: ${prefix + command} 30d`)
        db.data.sewa[from] = {
          id: from,
          expired: Date.now() + toMs(q)
        }
        reply(`*SEWA ADDED*\n\n*ID*: ${groupId}\n*EXPIRED*: ${ms(toMs(q)).days} days ${ms(toMs(q)).hours} hours ${ms(toMs(q)).minutes} minutes\n\nBot akan keluar secara otomatis dalam waktu yang sudah di tentukan.`)
      }
        break

      case 'delsewa': {
        if (!isOwner) return reply(mess.owner)
        if (!isGroup) return reply(mess.group)
        delete db.data.sewa[from]
        reply('Sukses delete sewa di group ini.')
      }
        break

      case 'ceksewa': {
        if (!isGroupAdmins && !isOwner) return reply(mess.admin)
        if (!isGroup) return reply(mess.group)
        if (!isSewa) return reply('Kamu belum sewa bot.')
        let cekExp = ms(db.data.sewa[from].expired - Date.now())
        reply(`*SEWA EXPIRED*\n\n*ID*: ${groupId}\n*SEWA EXPIRED*: ${cekExp.days} days ${cekExp.hours} hours ${cekExp.minutes} minutes`)
      }
        break

      case 'listsewa': {
        if (!isOwner) return reply(mess.owner)
        if (db.data.sewa == 0) return reply('Belum ada list sewa di database')
        let teks = '*LIST SEWA BOT*\n\n'
        let sewaKe = 0
        for (let i = 0; i < getAllSewa().length; i++) {
          sewaKe++
          teks += `${sewaKe}. ${getAllSewa()[i]}\n\n`
        }
        reply(teks)
      }
        break

      case 'welcome': {
        if (!isGroup) return reply(mess.group)
        if (!isGroupAdmins && !isOwner) return reply(mess.admin)
        if (!q) return reply(`Contoh: ${prefix + command} on/off`)
        if (q.toLowerCase() == "on") {
          if (db.data.chat[from].welcome) return reply('Welcome sudah aktif di grup ini.')
          db.data.chat[from].welcome = true
          reply('Sukses mengaktifkan welcome di grup ini.')
        } else if (q.toLowerCase() == "off") {
          if (!db.data.chat[from].welcome) return reply('Welcome sudah tidak aktif di grup ini.')
          db.data.chat[from].welcome = false
          reply('Sukses menonaktifkan welcome di grup ini.')
        }
      }
        break

      case 'antilink': {
        if (!isGroup) return reply(mess.group)
        if (!isGroupAdmins && !isOwner) return reply(mess.admin)
        if (!q) return reply(`Contoh: ${prefix + command} on/off`)
        if (q.toLowerCase() == "on") {
          if (db.data.chat[from].antilink) return reply('Antilink sudah aktif di grup ini.')
          db.data.chat[from].antilink = true
          reply('Sukses mengaktifkan antilink di grup ini.')
        } else if (q.toLowerCase() == "off") {
          if (!db.data.chat[from].antilink) return reply('Antilink sudah tidak aktif di grup ini.')
          db.data.chat[from].antilink = false
          reply('Sukses menonaktifkan antilink di grup ini.')
        }
      }
        break

      case 'antilinkv2': {
        if (!isGroup) return reply(mess.group)
        if (!isGroupAdmins && !isOwner) return reply(mess.admin)
        if (!q) return reply(`Contoh: ${prefix + command} on/off`)
        if (q.toLowerCase() == "on") {
          if (db.data.chat[from].antilink2) return reply('Antilinkv2 sudah aktif di grup ini.')
          db.data.chat[from].antilink2 = true
          reply('Sukses mengaktifkan antilinkv2 di grup ini.')
        } else if (q.toLowerCase() == "off") {
          if (!db.data.chat[from].antilink2) return reply('Antilinkv2 sudah tidak aktif di grup ini.')
          db.data.chat[from].antilink2 = false
          reply('Sukses menonaktifkan antilinkv2 di grup ini.')
        }
      }
        break

      case 'anticall': {
        if (!isOwner) return reply(mess.owner)
        if (!q) return reply(`Contoh: ${prefix + command} on/off`)
        if (q.toLowerCase() == "on") {
          if (db.data.chat[from].anticall) return reply('Anticall sudah aktif.')
          db.data.chat[from].anticall = true
          reply('Sukses mengaktifkan anticall.')
        } else if (q.toLowerCase() == "off") {
          if (!db.data.chat[from].anticall) return reply('Anticall sudah tidak aktif.')
          db.data.chat[from].anticall = false
          reply('Sukses menonaktifkan anticall.')
        }
      }
        break

      case 'setdone':
        if (!isGroup) return reply(mess.group)
        if (!isGroupAdmins && !isOwner) return reply(mess.admin)
        if (db.data.chat[from].sDone.length !== 0) return reply(`Set done sudah ada di group ini.`)
        if (!q) return reply(`Gunakan dengan cara *${prefix + command} teks*\n\nList function:\n@tag : untuk tag orang\n@tanggal\n@jam\n@status`)
        db.data.chat[from].sDone = q
        reply(`Sukses set done`)
        break

      case 'deldone':
        if (!isGroup) return reply(mess.group)
        if (!isGroupAdmins && !isOwner) return reply(mess.admin)
        if (db.data.chat[from].sDone.length == 0) return reply(`Belum ada set done di sini.`)
        db.data.chat[from].sDone = ""
        reply(`Sukses delete set done`)
        break

      case 'changedone':
        if (!isGroup) return reply(mess.group)
        if (!isGroupAdmins && !isOwner) return reply(mess.admin)
        if (!q) return reply(`Gunakan dengan cara *${prefix + command} teks*\n\nList function:\n@tag : untuk tag orang\n@tanggal\n@jam\n@status`)
        db.data.chat[from].sDone = q
        reply(`Sukses mengganti teks set done`)
        break

      case 'setproses':
        if (!isGroup) return reply(mess.group)
        if (!isGroupAdmins && !isOwner) return reply(mess.admin)
        if (db.data.chat[from].sProses.length !== 0) return reply(`Set proses sudah ada di group ini.`)
        if (!q) return reply(`Gunakan dengan cara *${prefix + command} teks*\n\nList function:\n@tag : untuk tag orang\n@tanggal\n@jam\n@status`)
        db.data.chat[from].sProses = q
        reply(`Sukses set proses`)
        break

      case 'delproses':
        if (!isGroup) return reply(mess.group)
        if (!isGroupAdmins && !isOwner) return reply(mess.admin)
        if (db.data.chat[from].sProses.length == 0) return reply(`Belum ada set proses di sini.`)
        db.data.chat[from].sProses = ""
        reply(`Sukses delete set proses`)
        break

      case 'changeproses':
        if (!isGroup) return reply(mess.group)
        if (!isGroupAdmins && !isOwner) return reply(mess.admin)
        if (!q) return reply(`Gunakan dengan cara *${prefix + command} teks*\n\nList function:\n@tag : untuk tag orang\n@tanggal\n@jam\n@status`)
        db.data.chat[from].sProses = q
        reply(`Sukses ganti teks set proses`)
        break

      case 'done': {
        if (!isGroup) return (mess.group)
        if (!isGroupAdmins && !isOwner) return (mess.admin)
        if (q.startsWith("@")) {
          if (db.data.chat[from].sDone.length !== 0) {
            let textDone = db.data.chat[from].sDone
            ronzz.sendMessage(from, { text: textDone.replace('tag', q.replace(/[^0-9]/g, '')).replace('@jam', jamwib).replace('@tanggal', tanggal).replace('@status', 'Berhasil'), mentions: [q.replace(/[^0-9]/g, '') + '@s.whatsapp.net'] });
          } else {
            ronzz.sendMessage(from, { text: `「 *TRANSAKSI BERHASIL* 」\n\n\`\`\`📆 TANGGAL : ${tanggal}\n⌚ JAM : ${jamwib}\n✨ STATUS: Berhasil\`\`\`\n\nTerimakasih @${q.replace(/[^0-9]/g, '')} next order yaa🙏`, mentions: [q.replace(/[^0-9]/g, '') + '@s.whatsapp.net'] }, { quoted: msg });
          }
        } else if (isQuotedMsg) {
          if (db.data.chat[from].sDone.length !== 0) {
            let textDone = db.data.chat[from].sDone
            ronzz.sendMessage(from, { text: textDone.replace('tag', quotedMsg.sender.split("@")[0]).replace('@jam', jamwib).replace('@tanggal', tanggal).replace('@status', 'Berhasil'), mentions: [quotedMsg.sender] }, { quoted: msg })
          } else {
            ronzz.sendMessage(from, { text: `「 *TRANSAKSI BERHASIL* 」\n\n\`\`\`📆 TANGGAL : ${tanggal}\n⌚ JAM : ${jamwib}\n✨ STATUS: Berhasil\`\`\`\n\nTerimakasih @${quotedMsg.sender.split("@")[0]} next order yaa🙏`, mentions: [quotedMsg.sender] })
          }
        } else {
          reply('Reply atau tag orangnya')
        }
      }
        break

      case 'proses':
        if (!isGroup) return (mess.group)
        if (!isGroupAdmins && !isOwner) return (mess.admin)
        if (isQuotedMsg) {
          if (db.data.chat[from].sProses.length !== 0) {
            let textProses = db.data.chat[from].sProses
            ronzz.sendMessage(from, { text: textProses.replace('tag', quotedMsg.sender.split("@")[0]).replace('@jam', jamwib).replace('@tanggal', tanggal).replace('@status', 'Pending'), mentions: [quotedMsg.sender] }, { quoted: msg });
          } else {
            ronzz.sendMessage(from, { text: `「 *TRANSAKSI PENDING* 」\n\n\`\`\`📆 TANGGAL : ${tanggal}\n⌚ JAM : ${jamwib}\n✨ STATUS: Pending\`\`\`\n\nPesanan @${quotedMsg.sender.split("@")[0]} sedang diproses🙏`, mentions: [quotedMsg.sender] });
          }
        } else if (q.startsWith("@")) {
          if (db.data.chat[from].sProses.length !== 0) {
            let textProses = db.data.chat[from].sProses
            ronzz.sendMessage(from, { text: textProses.replace('tag', q.replace(/[^0-9]/g, '')).replace('@jam', jamwib).replace('@tanggal', tanggal).replace('@status', 'Pending'), mentions: [q.replace(/[^0-9]/g, '') + '@s.whatsapp.net'] });
          } else {
            ronzz.sendMessage(from, { text: `「 *TRANSAKSI PENDING* 」\n\n\`\`\`📆 TANGGAL : ${tanggal}\n⌚ JAM : ${jamwib}\n✨ STATUS: Pending\`\`\`\n\nPesanan @${q.replace(/[^0-9]/g, '')} sedang diproses🙏`, mentions: [q.replace(/[^0-9]/g, '') + '@s.whatsapp.net'] }, { quoted: msg });
          }
        } else {
          reply('Reply atau tag orangnya')
        }
        break

      case 'list': {
        if (!isGroup) return reply(mess.group)
        if (db.data.list.length === 0) return reply(`Belum ada list message di database`)
        if (!isAlreadyResponListGroup(from)) return reply(`Belum ada list message yang terdaftar di group ini`)
        let x1 = false
        Object.keys(db.data.list).forEach((i) => {
          if (db.data.list[i].id == from) { x1 = i }
        })
        let teks = `Hai @${sender.split("@")[0]}\nBerikut list message di grup ini\n\n`
        for (let x of db.data.list) {
          if (x.id == from) {
            teks += `*LIST KEY:* ${x.key}\n\n`
          }
        }
        teks += `_Ingin melihat listnya?_\n_Ketik key saja_\n\n_Contoh:_\n${db.data.list[x1].key}`
        ronzz.sendMessage(from, { text: teks, mentions: [sender] }, { quoted: msg })
      }
        break

      case 'testi': {
        if (Object.keys(db.data.testi).length === 0) return reply(`Belum ada list testi di database`)
        let teks = `Hai @${sender.split("@")[0]}\nBerikut list testi owner saya\n\n`
        for (let x of db.data.testi) {
          teks += `*LIST KEY:* ${x.key}\n\n`
        }
        teks += `_Ingin melihat listnya?_\n_Ketik key saja_\n\n_Contoh:_\n${db.data.testi[0].key}`
        ronzz.sendMessage(from, { text: teks, mentions: [sender] }, { quoted: msg })
      }
        break

      case 'addlist': {
        if (!isGroup) return reply(mess.group)
        if (!isGroupAdmins && !isOwner) return reply(mess.admin)
        if (!q.includes("@")) return reply(`Gunakan dengan cara ${prefix + command} *key@response*\n\n_Contoh_\n\n${prefix + command} tes@apa`)
        if (isAlreadyResponList(from, q.split("@")[0])) return reply(`List respon dengan key : *${q.split("@")[0]}* sudah ada di group ini.`)
        if (isImage || isQuotedImage) {
          let media = await downloadAndSaveMediaMessage('image', `./options/sticker/${sender}.jpg`)
          let tph = await TelegraPh(media)
          addResponList(from, q.split("@")[0], q.split("@")[1], true, tph)
          reply(`Berhasil menambah list menu *${q.split("@")[0]}*`)
          fs.unlinkSync(media)
        } else {
          addResponList(from, q.split("@")[0], q.split("@")[1], false, '-')
          reply(`Berhasil menambah list menu : *${q.split("@")[0]}*`)
        }
      }
        break

      case 'addtesti': {
        if (isGroup) return reply(mess.private)
        if (!isOwner) return reply(mess.owner)
        if (isImage || isQuotedImage) {
          if (!q.includes("@")) return reply(`Gunakan dengan cara ${prefix + command} *key@response*\n\n_Contoh_\n\n${prefix + command} tes@apa`)
          if (isAlreadyResponTesti(q.split("@")[0])) return reply(`List respon dengan key : *${q.split("@")[0]}* sudah ada.`)
          let media = await downloadAndSaveMediaMessage('image', `./options/sticker/${sender}.jpg`)
          let tph = await TelegraPh(media)
          addResponTesti(q.split("@")[0], q.split("@")[1], true, tph)
          reply(`Berhasil menambah list testi *${q.split("@")[0]}*`)
          fs.unlinkSync(media)
        } else {
          reply(`Kirim gambar dengan caption ${prefix + command} *key@response* atau reply gambar yang sudah ada dengan caption ${prefix + command} *key@response*`)
        }
      }
        break

      case 'dellist':
        if (!isGroup) return reply(mess.group)
        if (!isGroupAdmins && !isOwner) return reply(mess.admin)
        if (db.data.list.length === 0) return reply(`Belum ada list message di database`)
        if (!q) return reply(`Gunakan dengan cara ${prefix + command} *key*\n\n_Contoh_\n\n${prefix + command} hello`)
        if (!isAlreadyResponList(from, q)) return reply(`List respon dengan key *${q}* tidak ada di database!`)
        delResponList(from, q)
        reply(`Sukses delete list message dengan key *${q}*`)
        break

      case 'deltesti':
        if (isGroup) return reply(mess.private)
        if (!isOwner) return reply(mess.owner)
        if (db.data.testi.length === 0) return reply(`Belum ada list testi di database`)
        if (!q) return reply(`Gunakan dengan cara ${prefix + command} *key*\n\n_Contoh_\n\n${prefix + command} hello`)
        if (!isAlreadyResponTesti(q)) return reply(`List testi dengan key *${q}* tidak ada di database!`)
        delResponTesti(q)
        reply(`Sukses delete list testi dengan key *${q}*`)
        break

      case 'setlist': {
        if (!isGroup) return reply(mess.group)
        if (!isGroupAdmins && !isOwner) return reply(mess.admin)
        if (!q.includes("@")) return reply(`Gunakan dengan cara ${prefix + command} *key@response*\n\n_Contoh_\n\n${prefix + command} tes@apa`)
        if (!isAlreadyResponList(from, q.split("@")[0])) return reply(`List respon dengan key *${q.split("@")[0]}* tidak ada di group ini.`)
        if (isImage || isQuotedImage) {
          let media = await downloadAndSaveMediaMessage('image', `./options/sticker/${sender}.jpg`)
          let tph = await TelegraPh(media)
          updateResponList(from, q.split("@")[0], q.split("@")[1], true, tph)
          reply(`Berhasil mengganti list menu *${q.split("@")[0]}*`)
          fs.unlinkSync(media)
        } else {
          updateResponList(from, q.split("@")[0], q.split("@")[1], false, '-')
          reply(`Berhasil mengganti List menu : *${q.split("@")[0]}*`)
        }
      }
        break

      case 'settesti': {
        if (!isOwner) return reply(mess.owner)
        if (!q.includes("@")) return reply(`Gunakan dengan cara ${prefix + command} *key@response*\n\n_Contoh_\n\n${prefix + command} tes@apa`)
        if (!isAlreadyResponTesti(q.split("@")[0])) return reply(`List testi dengan key *${q.split("@")[0]}* tidak ada di database.`)
        if (isImage || isQuotedImage) {
          let media = await downloadAndSaveMediaMessage('image', `./options/sticker/${sender}.jpg`)
          let tph = await TelegraPh(media)
          updateResponTesti(q.split("@")[0], q.split("@")[1], true, tph)
          reply(`Berhasil mengganti list testi *${q.split("@")[0]}*`)
          fs.unlinkSync(media)
        } else {
          reply(`Kirim gambar dengan caption ${prefix + command} *key@response* atau reply gambar yang sudah ada dengan caption ${prefix + command} *key@response*`)
        }
      }
        break

      case 'open':
        if (!isGroup) return reply(mess.group)
        if (!isGroupAdmins && !isOwner) return reply(mess.admin)
        if (!isBotGroupAdmins) return reply(mess.botAdmin)
        await ronzz.groupSettingUpdate(from, 'not_announcement')
        await reply(`Sukses mengizinkan semua peserta dapat mengirim pesan ke grup ini.`)
        break

      case 'close':
        if (!isGroup) return reply(mess.group)
        if (!isGroupAdmins && !isOwner) return reply(mess.admin)
        if (!isBotGroupAdmins) return reply(mess.botAdmin)
        await ronzz.groupSettingUpdate(from, 'announcement')
        await reply(`Sukses mengizinkan hanya admin yang dapat mengirim pesan ke grup ini.`)
        break

      case 'hidetag': case 'ht': case 'h': {
        if (!isGroup) return reply(mess.group)
        if (!isGroupAdmins && !isOwner) return reply(mess.admin)
        let mem = groupMembers.map(i => i.id)
        ronzz.sendMessage(from, { text: q ? q : '', mentions: mem })
      }
        break

      case 'kalkulator': {
        if (!q) return reply(`Contoh: ${prefix + command} + 5 6\n\nList kalkulator:\n+\n-\n÷\n×`)
        if (q.split(" ")[0] == "+") {
          let q1 = Number(q.split(" ")[1])
          let q2 = Number(q.split(" ")[2])
          reply(`${q1 + q2}`)
        } else if (q.split(" ")[0] == "-") {
          let q1 = Number(q.split(" ")[1])
          let q2 = Number(q.split(" ")[2])
          reply(`${q1 - q2}`)
        } else if (q.split(" ")[0] == "÷") {
          let q1 = Number(q.split(" ")[1])
          let q2 = Number(q.split(" ")[2])
          reply(`${q1 / q2}`)
        } else if (q.split(" ")[0] == "×") {
          let q1 = Number(q.split(" ")[1])
          let q2 = Number(q.split(" ")[2])
          reply(`${q1 * q2}`)
        }
      }
        break

      case 'kick': {
        if (!isGroup) return reply(mess.group)
        if (!isGroupAdmins) return reply(mess.admin)
        if (!isBotGroupAdmins) return reply(mess.botAdmin)
        let number;
        if (q.length !== 0) {
          number = q.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
          ronzz.groupParticipantsUpdate(from, [number], "remove")
            .then(res => reply('Sukses...'))
            .catch((err) => reply(mess.error.api))
        } else if (isQuotedMsg) {
          number = quotedMsg.sender
          ronzz.groupParticipantsUpdate(from, [number], "remove")
            .then(res => reply('Sukses...'))
            .catch((err) => reply(mess.error.api))
        } else {
          reply('Tag atau balas pesan orang yang ingin dikeluarkan dari grup.')
        }
      }
        break

      case 'promote': {
        if (!isGroup) return reply(mess.group)
        if (!isGroupAdmins) return reply(mess.admin)
        if (!isBotGroupAdmins) return reply(mess.botAdmin)
        let number;
        if (q.length !== 0) {
          number = q.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
          ronzz.groupParticipantsUpdate(from, [number], "promote")
            .then(res => ronzz.sendMessage(from, { text: `Sukses menjadikan @${number.split("@")[0]} sebagai admin`, mentions: [number] }, { quoted: msg }))
            .catch((err) => reply(mess.error.api))
        } else if (isQuotedMsg) {
          number = quotedMsg.sender
          ronzz.groupParticipantsUpdate(from, [number], "promote")
            .then(res => ronzz.sendMessage(from, { text: `Sukses menjadikan @${number.split("@")[0]} sebagai admin`, mentions: [number] }, { quoted: msg }))
            .catch((err) => reply(mess.error.api))
        } else {
          reply('Tag atau balas pesan orang yang ingin dijadikan admin.')
        }
      }
        break

      case 'demote': {
        if (!isGroup) return reply(mess.group)
        if (!isGroupAdmins) return reply(mess.admin)
        if (!isBotGroupAdmins) return reply(mess.botAdmin)
        let number;
        if (q.length !== 0) {
          number = q.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
          ronzz.groupParticipantsUpdate(from, [number], "demote")
            .then(res => ronzz.sendMessage(from, { text: `Sukses menjadikan @${number.split("@")[0]} sebagai anggota group`, mentions: [number] }, { quoted: msg }))
            .catch((err) => reply(mess.error.api))
        } else if (isQuotedMsg) {
          number = quotedMsg.sender
          ronzz.groupParticipantsUpdate(from, [number], "demote")
            .then(res => ronzz.sendMessage(from, { text: `Sukses menjadikan @${number.split("@")[0]} sebagai anggota group`, mentions: [number] }, { quoted: msg }))
            .catch((err) => reply(mess.error.api))
        } else {
          reply('Tag atau balas pesan orang yang ingin dijadikan anggota group.')
        }
      }
        break

      case 'revoke':
        if (!isGroup) return reply(mess.group)
        if (!isGroupAdmins) return reply(mess.admin)
        if (!isBotGroupAdmins) return reply(mess.botAdmin)
        await ronzz.groupRevokeInvite(from)
          .then(res => {
            reply('Sukses menyetel tautan undangan grup ini.')
          }).catch(() => reply(mess.error.api))
        break

      case 'linkgrup': case 'linkgroup': case 'linkgc': {
        if (!isGroup) return reply(mess.group)
        if (!isBotGroupAdmins) return reply(mess.botAdmin)
        let url = await ronzz.groupInviteCode(from).catch(() => reply(mess.errorApi))
        url = 'https://chat.whatsapp.com/' + url
        reply(url)
      }
        break

      case 'delete':
        if (!isGroup) return reply(mess.group)
        if (!isGroupAdmins && !isOwner) return reply(mess.admin)
        if (quotedMsg == null) return reply("Reply chat dari bot yang ingin dihapus")
        if (quotedMsg.fromMe !== true) return reply("Chat tersebut bukan dari bot")
        ronzz.sendMessage(from, { delete: { fromMe: true, id: quotedMsg.id, remoteJid: from } })
        break

      case 'blok': case 'block':
        if (!isOwner && !fromMe) return reply(mess.owner)
        if (!q) return reply(`Contoh: ${prefix + command} 628xxx`)
        await ronzz.updateBlockStatus(q.replace(/[^0-9]/g, '') + '@s.whatsapp.net', "block") // Block user
        reply('Sukses block nomor.')
        break

      case 'unblok': case 'unblock':
        if (!isOwner && !fromMe) return reply(mess.owner)
        if (!q) return reply(`Contoh: ${prefix + command} 628xxx`)
        await ronzz.updateBlockStatus(q.replace(/[^0-9]/g, '') + '@s.whatsapp.net', "unblock") // Block user
        reply('Sukses unblock nomor.')
        break

      case 'script': case 'sc':
        reply(`*SCRIPT NO ENC*\nMau beli scriptnya?\n\n*Contact Person 📞*\nwa.me/6281904092095\n\n*Harga* 💰\nRp30.000 (30k)\nHarga terlalu mahal?\nNego tipis aja\n\n*Payment* 💳\n_Qris / Dana_\n\nSudah termasuk tutorial.\nKalau error difixs.\nPasti dapet update dari *R¡zzxteam.*\nSize script ringan.\nAnti ngelag/delay.`)
        break

      case 'owner':
        ronzz.sendContact(from, [ownerNomer], msg)
        break

      case 'creator':
        ronzz.sendMessage(from, { text: 'Creator sc ini adalah\n@6282230002820 (R¡zzxteam Hosting)', mentions: ['6282230002820@s.whatsapp.net'] }, { quoted: msg })
        break

      case 'tes': case 'runtime':
        reply(`*STATUS : BOT ONLINE*\n_Runtime : ${runtime(process.uptime())}_`)
        break

      case 'ping':
        let timestamp = speed()
        let latensi = speed() - timestamp
        reply(`Kecepatan respon _${latensi.toFixed(4)} Second_\n\n*💻 INFO SERVER*\nHOSTNAME: ${os.hostname}\nRAM: ${formatp(os.totalmem() - os.freemem())} / ${formatp(os.totalmem())}`)
        break

      default:
        if (budy.startsWith('=>')) {
          if (!isOwner) return
          function Return(sul) {
            sat = JSON.stringify(sul, null, 2)
            bang = util.format(sat)
            if (sat == undefined) {
              bang = util.format(sul)
            }
            return reply(bang)
          }
          try {
            reply(util.format(eval(`(async () => { ${budy.slice(3)} })()`)))
          } catch (e) {
            reply(String(e))
          }
        }
        if (budy.startsWith('>')) {
          if (!isOwner) return
          try {
            let evaled = await eval(budy.slice(2))
            if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
            await reply(evaled)
          } catch (err) {
            reply(String(err))
          }
        }
        if (budy.startsWith('$')) {
          if (!isOwner) return
          let qur = budy.slice(2)
          exec(qur, (err, stdout) => {
            if (err) return reply(err)
            if (stdout) {
              reply(stdout)
            }
          })
        }
    }
  } catch (err) {
    console.log(color('[ERROR]', 'red'), err)
  }
}